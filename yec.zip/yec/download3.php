<?php
  header('Content-Disposition:attachment;filename="photo.zip"');
  //
  readfile('./photo.zip');

?>