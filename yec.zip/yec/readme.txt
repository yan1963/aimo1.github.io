1.复制phpStudy_64.zip 到D盘解压和安装
2.复制download7-21.php ,download7-23.php,my_result.php,index2.html 到 D:\phpstudy_pro\www\
3.在Setup1文件夹中安装，开始运行几次可成功。