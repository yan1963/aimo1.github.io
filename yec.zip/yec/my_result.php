<?php
$name = $_POST['name'];
echo "Hello, $name!";
// 获取表单提交的数据
//$name = $_POST['name']; // 名字
//$email = $_POST['email']; // 邮箱
 
// 打开或创建要保存数据的TXT文件
$file = fopen('c:\data.txt', 'w');
if ($file) {
    $content = "{$name}";
    
    // 将内容追加到文件末尾
    fwrite($file, $content);
    
    // 关闭文件
    fclose($file);
    
    echo "数据已成功保存到TXT文件！";
} else {
    echo "无法打开或创建文件！";
}
?>