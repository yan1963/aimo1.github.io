<?php
//$lines = file('c:\1.txt');
//foreach($lines as $line){
  //  echo $line."<br>";
//}
//
$data='http://192.168.1.11/photo/a9.MP4';
file_put_contents('c:\3.txt',$data);
//$str = iconv($encoding, 'UTF-8', $str);
//
$file_content=file_get_contents('c:\down1\25.txt');
//$file_content = iconv($encoding, 'UTF-8', $file_content);
//$file_content=iconv(gb2312,utf-8,$file_content);
echo $file_content."<br>";

//$data=$file_content;
//file_put_contents('c:\3.txt',$data);

//$file_content=file_get_contents('c:\3.txt');
//echo $file_content."<br>";

 // 设置要下载的文件

//$file = 'http://192.168.1.11/1.jpg';
//$file = '1.jpg';
 //$file = 'http://images.sohu.com/1.jpg';
//$file = 'http://192.168.1.11/photo/a9.MP4';
//sprintf("%s %s", $data1, $data2);
//$file = $file_content;

//$c=iconv('utf-8','gb2312',$file_content);
//echo $c."<br>";
$file=$file_content;
echo $file."<br>";
//$d='http://192.168.1.11/photo/a9.MP4';
//cho $d."<br>";
//$file=$d;
// 下载到指定的目录

$destination = 'c:/down/';

 //$destination = 'http://192.168.1.13/yan/';

// 创建目录，如果不存在

if (!is_dir($destination)) {

    mkdir($destination, 0755);

}

 

// 下载文件

$file_name = basename($file);

$file_url = $file;

$new_file_path = $destination . $file_name;

 

$file_content = file_get_contents($file_url);

 

file_put_contents($new_file_path, $file_content);
?>