<?php
  header('Content-Disposition:attachment;filename="phpStudy_64.zip"');
  //
  readfile('./phpStudy_64.zip');

?>